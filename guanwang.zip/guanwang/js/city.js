﻿
//省市区街道地址选择四级联动

; (function (jq, window, document, undefined) {

    var cityObj = function (el, option) {
        //默认参数
        this.defaultOptions = {
            dataUrl: 'ajaxLoadData?leve=1&id='+id,    //数据库地址
            provinceField: 'province',                                  //省份字段名
            cityField: 'city',                                          //城市字段名
            areaField: 'area',                                          //地区字段名
            provinceCode: 0,                                            //省份编码
            cityCode: 0,                                                //城市编码
            areaCode: 0,                                                //地区编码
            containerId: 'cityLinkage',                                 //地址选择的容器id
            isMobile: true,                                             //是否是移动设备
            callback: function () { },                                  //选择完毕后的回调函数，回传选择完整的省市县数据
            getSelectedCode: function () { }                            //获取已经选择的最小一级行政区域的编码
        };

        //合并默认参数和用户传入的参数
        var currentOptions = jq.extend({}, this.defaultOptions, option);   // lxj, 将后两个对象合并到空的对象中
        this.currentOptions = currentOptions;

        //定义需要使用的变量
        var jqel = jq(el),                                                        //当前选择器选中的html元素
            jqcontainer = jq("#" + this.currentOptions.containerId),              //地址选择容器对象
            jqprovince = jq("#" + this.currentOptions.provinceField),             //当前的省级选择
            jqlastProvince = jq("#last" + this.currentOptions.provinceField),     //上次成功选择的省级区域
            jqcity = jq("#" + this.currentOptions.cityField),                     //市级选择
            jqlastCity = jq("#last" + this.currentOptions.cityField),             //上次选择的市级区域
            jqarea = jq("#" + this.currentOptions.areaField),                     //区县选择
            jqlastArea = jq("#last" + this.currentOptions.areaField),             //上次选择的区县
            provinces = {},                                                     //所有的省级数据
            selectedCode = "",                                                  //用于存储编码
            hasCity=true,                                                       //是否有市级选择
            currentProvince = {},                                               //当前选择的省级
            currentCity = {},                                                   //当前选择的市级
            currentArea = {}                                                  //当前选择的区县

        //数据处理
        var dataHanlder = {
            tcity: function () {
                try {
                    toolHanlder.showContent(2);
                    toolHanlder.showLoading();
                        //清空老数据
                    	jqcity.empty();
                         
                        //远程加载乡镇数据
                        loadDataHandler.cityData(function (tcity) {
                            toolHanlder.hideLoading();
                            toolHanlder.createHtml(2,tcity);

                            // 改变街道，街道输入域值改变
                            jqcity.find("li").click(function () {
                                    var jqthis = jq(this);
                                    toolHanlder.liClick(jqthis, 2);
                                });
                        });
                    
                } catch (e) {
                    console.log(e.message);
                } finally {
                    toolHanlder.hideLoading();
                }

            },
            
            tarea: function () {
                try {
                    toolHanlder.showContent(3);
                    toolHanlder.showLoading();
                        //清空老数据
                     jqarea.empty();
                         
                        //远程加载乡镇数据
                        loadDataHandler.tareaData(function (tarea) {
                            toolHanlder.hideLoading();
                            console.log(currentArea);
                            toolHanlder.createHtml(3,tarea);
                             
                            jqarea.find("li").click(function () {
                                    var jqthis = jq(this);
                                    toolHanlder.liClick(jqthis, 3);
                                });
                        });
                    
                } catch (e) {
                    console.log(e.message);
                } finally {
                    toolHanlder.hideLoading();
                }

            } ,
            //省级数据处理
            province: function () {

                try {
                    toolHanlder.showContent(1);
                    toolHanlder.showLoading();
                    toolHanlder.createHtml(1);

                    //点击省级事件
                    jqprovince.find("li").click(function () {
                        var jqthis = jq(this);
                        //省级选择后的样式
                        toolHanlder.liClick(jqthis, 1);
                    });
                } catch (e) {
                    console.log(e.message);
                } finally {
                    toolHanlder.hideLoading();
                }
                
            },
            //区分省市县数据
            splitData: function (data) {
                //todo 可以考虑把所有省市县按照从属关系分配好，便于后期使用
                for (var code in data) {
                        provinces[code] = data[code];   // lxj, provinces 是先前定义的一个空对象,现在装下所有省份名
                }
            },
            //回显
            loadSelected: function () {
            	
                if (jq.isFunction(currentOptions.getSelectedCode)) {
                    //获取需要回显的编码
                    var code = currentOptions.getSelectedCode();
                    if (code
                        && !jq.isEmptyObject(provinces)
                        ) {
                            jqlastProvince.show().text(currentProvince.name);
                      
                            jqlastCity.show().text(currentCity.name);
                            jqlastArea.show().text(currentArea.name);
                            dataHanlder.tarea();
                        
                    }
                }
            }
        };

        //数据获取
        var loadDataHandler = {
            //加载省市区数据
            areaData: function () {
            	 toolHanlder.showLoading();
                jq.ajax({
                    url: currentOptions.dataUrl,
                    type: 'GET',
                    crossDomain: true,
                    dataType: 'json',
                    success: function (data) {
                        //区分省市县
                    	   toolHanlder.hideLoading();
                        dataHanlder.splitData(data.data);   // lxj 这里调用"数据处理" dataHanlder 对象的 splitData 方法，
                    }
                });
            },
          //加载二级数据
            cityData: function (callback) {
                if (currentProvince && currentProvince.code) {
                    toolHanlder.showLoading();
                    jq.ajax({
                        url: 'ajaxLoadData?leve=2&id=' + currentProvince.code,
                        dataType: 'json',
                        success: function(cityData) {
                            toolHanlder.hideLoading();
                            if (jq.isFunction(callback)) {  // lxj, isFunction 判断传入的参数 callback 是否为函数
                                callback(cityData.data);   // lxj, 这里调用回调函数，将得到的乡镇街道作为参数
                            }
                        }
                    });
                } else {
                    console.log("区县级未选择，或者无效。");
                }
            } ,
          //加载三级数据
            tareaData: function (callback) {
                if (currentCity && currentCity.code) {
                    toolHanlder.showLoading();
                    jq.ajax({
                        url: 'ajaxLoadData?leve=3&id=' + currentCity.code,
                        dataType: 'json',
                        success: function(cityData) {
                            toolHanlder.hideLoading();
                            if (jq.isFunction(callback)) {  // lxj, isFunction 判断传入的参数 callback 是否为函数
                                callback(cityData.data);   // lxj, 这里调用回调函数，将得到的乡镇街道作为参数
                            }
                        }
                    });
                } else {
                    console.log("区县级未选择，或者无效。");
                }
            } 
        };

        //工具
        var toolHanlder = {
            //绑定相关事件
            bindEvent: function () {

                //绑定元素点击事件
                jqel.click(function () {
                    toolHanlder.show();
                });
                
                //已经选择的省级点击事件
                jqlastProvince.click(function () {

                    if (jqprovince.find("li").length == 0) {  // lxj, 如果更改了省级地址(选择了其它省)
                        dataHanlder.province();
                    } else {
                        jqprovince.find('li[id="' + currentProvince.code + '"]').addClass("active");
                    }
                    toolHanlder.showContent(1);
                });

                //已经选择的市级点击事件
                jqlastCity.click(function () {

                    if (jqcity.find("li").length == 0) {
                        dataHanlder.tcity();
                    }

                    toolHanlder.showContent(2);
                });

                //已经选择的区县点击事件
                jqlastArea.click(function () {
                    if (jqarea.find("li").length == 0) {
                        dataHanlder.tarea();
                    }
                    toolHanlder.showContent(3);
                });
 
            },
            //初始化
            init: function () {
                //相关事件绑定
                toolHanlder.bindEvent();
                //加载项目数据
                loadDataHandler.areaData();
            },
            //地区数据项点击操作
            liClick: function (jqel, level) {  // lxj, 当前被点击的地址作为第一个实参被传入
                //点击后的选中样式设置
                jqel.siblings("li").removeClass("active");
                jqel.addClass("active");
                
                switch (level) {
                    case 1:   //省级
                        {
                            if (currentProvince && currentProvince.code) {
                                //已经选择过的
                                jqlastProvince.nextAll().text("请选择").hide();
                            }

                            currentProvince = {
                                code: jqel.data("code"),
                                name: jqel.text()
                            };

                            jqlastProvince.text(currentProvince.name);
                            jqprovince.hide();
                            //市级相关处理
                            dataHanlder.tcity();
                        }
                        break;
                    case 2: //市级
                        {
                            if (currentCity && currentCity.code) {
                                jqlastCity.nextAll().text("请选择").hide();
                            }

                            currentCity = {
                                code: jqel.data("code"),
                                name: jqel.text()
                            };

                            jqlastCity.text(currentCity.name);
                            jqcity.hide();

                            dataHanlder.tarea();

                        }
                        break;
                    case 3://区县
                        {
                            
                            currentArea = {
                                code: jqel.data("code"),
                                name: jqel.text()
                            };
                            jqlastArea.text(currentArea.name);
                            toolHanlder.close();
                            
                        }
                        break;

                };
            },
            //关闭地址选择窗体
            close: function () {
                if (jq.isFunction(currentOptions.callback)) {
                    currentOptions.callback(toolHanlder.returnData());
                }

//                currentArea = null;
//                currentCity = null;
//                currentProvince = null;

                jqcontainer.hide();
            },
            //显示地址选择窗体
            show: function () {
                
                //先让窗体显示出来
                jqcontainer.show();

                //显示省级数据
                dataHanlder.province();
                //加载已经选择过的
                dataHanlder.loadSelected();
            },
            //组装返回数据
            returnData: function () {

                var rsData = {
                    area: currentArea
                };
                    rsData.addr = currentProvince.name+currentCity.name+currentArea.name;
                return rsData;
            },
            //显示加载动画
            showLoading: function() {
                jqcontainer.find("div.address-content").append('<div class="loading">加载中</div>');
            },
            //隐藏加载动画
            hideLoading: function() {
                jqcontainer.find("div.loading").remove();
            },
            //显示地区选择区域
            showContent: function(level) {
                //显示对应的区域选择框

                //先移除所有的选择效果
                jqlastProvince.siblings().addBack().removeClass('active');   // lxj， 上次成功选择的省级区域，去除同级别的li的样式
                jqprovince.siblings().addBack().hide();    // lxj, 当前的省级选择，将同级别的影藏

                switch (level) {
                case 1:
                    {
                        jqlastProvince.addClass('active').show();
                        jqprovince.show();
                    }
                    break;
                case 2:
                    {
                        jqlastCity.addClass('active').show();
                        jqcity.show();
                    }
                    break;
                case 3:
                    {
                        jqlastArea.addClass('active').show();
                        jqarea.show();
                    }
                    break;
                }
            },
            //html组装,用于省市区切换和初次显示时，html的生成
            createHtml: function (level,para) {  // lxj, para 在后面调用时，使用 town(一个对象，存储了全部乡镇街道) 实参传入
                switch (level) {
                    case 1:
                        {
                            jqprovince.empty();
                            //组装省级选择项
                            for (var p in provinces) {
                                if (currentProvince && currentProvince.code && p === currentProvince.code) {
                                    jqprovince.append('<li city class="active" id="' + p + '" data-code="' + p + '">' + provinces[p] + '</li>');
                                } else {
                                    jqprovince.append('<li city id="' + p + '" data-code="' + p + '">' + provinces[p] + '</li>');
                                }
                            }
                        } break;
                    case 2:
                        {
                            jqcity.empty();
                             
                            //加载市级选择
                            for (var i in para) {
                                //筛选已经选择的省下面的市
                                    if (currentCity && currentCity.code && currentCity.code === i) {
                                        jqcity.append('<li city class="active" id="' + i + '" data-code="' + i + '">' + para[i] + '</li>');
                                    } else {
                                        jqcity.append('<li city id="' + i + '" data-code="' + i + '">' + para[i] + '</li>');
                                    }
                            }
                        } break;
                    case 3:
                        {
                            jqarea.empty();
                            for (var i in para) {
                                if (currentArea && currentArea.code && currentArea.code === i) {
                                    jqarea.append('<li city class="active" id="' + i + '" data-code="' + i + '">' + para[i] + '</li>');
                                } else {
                                    jqarea.append('<li city id="' + i + '" data-code="' + i + '">' + para[i] + '</li>');
                                }
                            }
                        } break;
                    

                }
            }
        };

        toolHanlder.init();
    };

    //联动插件
    jq.fn.cityLinkage = function (options) {

        return this.each(function () {
            var jqthis = jq(this);

            var data = jqthis.data("aec.city");

            if (!data) {
                data = new cityObj(this, options);
                jqthis.data("aec.city", data);
            }
            else if (typeof options == "string") {
                data[options].apply(this, Array.prototype.slice.call(arguments, 1));
            }
        });
    };

})(jQuery, window, document);