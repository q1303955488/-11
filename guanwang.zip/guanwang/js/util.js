//自定义公用js
var setting = {
	priceScale: 2,//	价格精确位数=	site.price_precision
	priceRoundType: 4, 	//	价格精确方式=	site.price_accurate_way 
	currencySign: "￥",
	currencyUnit: "元",
	uploadImageExtension: "jpg,jpeg,bmp,gif,png",
	uploadFlashExtension: "swf,flv",
	uploadMediaExtension: "swf,flv,mp3,wav,avi,rm,rmvb",
	uploadFileExtension: "zip,rar,7z,doc,docx,xls,xlsx,ppt,pptx"
};


//货币格式化
function currency(value, showSign, showUnit) {
	if (value != null) {
		var price;
		
		if (setting.priceRoundType == "4") {
			price = (Math.round(value * Math.pow(10, setting.priceScale)) / Math.pow(10, setting.priceScale))
.toFixed(setting.priceScale);
		} else if (setting.priceRoundType == "0") {
			price = (Math.ceil(value * Math.pow(10, setting.priceScale)) / Math.pow(10, setting.priceScale)).toFixed
(setting.priceScale);
		} else {
			price = (Math.floor(value * Math.pow(10, setting.priceScale)) / Math.pow(10, setting.priceScale))
.toFixed(setting.priceScale);
		}
		
		if (showSign) {
			price = setting.currencySign + price;
		}
		if (showUnit) {
			price += setting.currencyUnit;
		}
		return price;
	}
}


//邮箱格式验证
function checkEmail(value) {
	if (value == "") {
		return false;
	}
	if (!value.match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)) {
		return false;
	}
	return true;
}

//手机格式验证
function checkMobile(value) {
	if (value == "") {
		return false;
	}

	if (!value.match(/^1[3|4|5|7|8][0-9]\d{4,8}$/)) {
		return false;
	}
	return true;
}

//身份证格式验证
function checkCardNo(card) {
	// 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
	var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
	if (reg.test(card) === false) {
		return false;
	}

	return true;
}
 
 
//
 
 

//得到当前时间 格式“yyyy-MM-dd HH:MM:SS”
function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + (date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds());
    return currentdate;
}

//当前日期加减天
function getNowFormatDate(d) {
	var date = new Date();
	date.setDate(date.getDate() + d);
	var seperator1 = "-";
	var seperator2 = ":";
	var month = date.getMonth() + 1;
	var strDate = date.getDate();
	if (month >= 1 && month <= 9) {
		month = "0" + month;
	}
	if (strDate >= 0 && strDate <= 9) {
		strDate = "0" + strDate;
	}
	var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
	return currentdate;
}
//当前日期 2012-01-01
function getFormatDate() {
	var date = new Date();

	var seperator1 = "-";
	var seperator2 = ":";
	var month = date.getMonth() + 1;
	var strDate = date.getDate();
	if (month >= 1 && month <= 9) {
		month = "0" + month;
	}
	if (strDate >= 0 && strDate <= 9) {
		strDate = "0" + strDate;
	}
	var currentdate = date.getFullYear() + seperator1 + month + seperator1 + "01";
	return currentdate;
}

//时间对比
function comptime(beginTime,endTime) {
	     var date1 = new Date(beginTime.replace(/\-/g, "\/"));
	    var date2 = new Date(endTime.replace(/\-/g, "\/"));
	    var a = date2-date1;
	    if (a < 0) {
	       // alert("endTime小!");
		   return false;
	    } else if (a > 0) {
	       // alert("endTime大!");
		   return true;
	    } else if (a == 0) {
	        return true;
	    } else {
	        return false;
	    }
}
